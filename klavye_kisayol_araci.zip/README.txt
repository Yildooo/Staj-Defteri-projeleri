
Klavye Kisayol Araci (C++)

Bu program Windows icin global klavye kisayolu tanimlar.

Varsayilan kisayol:
CTRL + ALT + K

Derleme (MinGW):
g++ klavye_kisayol.cpp -o kisayol.exe -mwindows

Derleme (MSVC):
cl klavye_kisayol.cpp user32.lib
