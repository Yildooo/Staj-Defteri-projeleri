
#include <windows.h>
#include <iostream>

#define HOTKEY_ID 1

int main() {
    // CTRL + ALT + K
    if (!RegisterHotKey(NULL, HOTKEY_ID, MOD_CONTROL | MOD_ALT, 0x4B)) {
        std::cout << "Kisayol kaydedilemedi!" << std::endl;
        return 1;
    }

    std::cout << "Kisayol aktif: CTRL + ALT + K\n";
    std::cout << "Cikmak icin programi kapatin.\n";

    MSG msg = {0};
    while (GetMessage(&msg, NULL, 0, 0)) {
        if (msg.message == WM_HOTKEY) {
            MessageBox(NULL, "Kisayol Calisti!", "Bilgi", MB_OK | MB_ICONINFORMATION);
        }
    }

    UnregisterHotKey(NULL, HOTKEY_ID);
    return 0;
}
